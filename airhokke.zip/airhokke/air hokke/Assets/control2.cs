﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class control2 : MonoBehaviour
{
    public Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        Transform myTransform = this.transform;
        if (Input.GetKey(KeyCode.UpArrow))
        {
            myTransform.Translate(0, 0, 0.5f);
            //rb.AddForce(0, 0, 10, ForceMode.Impulse);
        }
        if (Input.GetKey(KeyCode.DownArrow))
        {
            myTransform.Translate(0, 0, -0.5f);
            //rb.AddForce(0, 0, -10, ForceMode.Impulse);
        }
    }
}
